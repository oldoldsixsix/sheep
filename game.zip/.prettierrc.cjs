/**
 * prettier config
 * @ref https://prettier.io/
 * @desc generated at 9/15/2022, 12:51:48 PM by streakingman-cli@1.9.2
 */

module.exports = {
    tabWidth: 4,
    singleQuote: true,
    htmlWhitespaceSensitivity: 'css',
    endOfLine: 'lf'
}
