import React, { FC } from 'react';

export const GithubIcon: FC = () => {
    return (
        <p>
            点个✨不迷路
        </p>
    );
};
